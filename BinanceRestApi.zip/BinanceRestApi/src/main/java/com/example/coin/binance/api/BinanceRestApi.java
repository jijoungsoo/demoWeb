package com.example.coin.binance.api;

import com.example.coin.binance.MarketDataEndPointsGetApiV3TickerPriceChangeStatistics24;
import com.example.coin.binance.WalletEndPointsGetSapiV1AllCoinsInformation;

import dataset.DataSet;
import running.common.SAProxy;

public class BinanceRestApi  extends SAProxy {
    public DataSet WalletEndPointsGetSapiV1AllCoinsInformation(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	WalletEndPointsGetSapiV1AllCoinsInformation tmp = new WalletEndPointsGetSapiV1AllCoinsInformation();
    	DataSet OUT_DS =tmp.GetSapiV1AllCoinsInformation(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    public DataSet MarketDataEndPointsGetApiV3Time(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3Time tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3Time();
    	DataSet OUT_DS =tmp.GetApiV3Time(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }

    public DataSet MarketDataEndPointsGetApiV3Ping(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3Ping tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3Ping();
    	DataSet OUT_DS =tmp.GetApiV3Ping(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    public DataSet MarketDataEndPointsGetApiV3ExchangeInfo(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3ExchangeInfo tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3ExchangeInfo();
    	DataSet OUT_DS =tmp.GetApiV3ExchangeInfo(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    public DataSet MarketDataEndPointsGetApiV3OrderBook(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3OrderBook tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3OrderBook();
    	DataSet OUT_DS =tmp.GetApiV3OrderBook(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    public DataSet MarketDataEndPointsGetApiV3RecentTradesList(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3RecentTradesList tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3RecentTradesList();
    	DataSet OUT_DS =tmp.GetApiV3RecentTradesList(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    public DataSet MarketDataEndPointsGetApiV3TickerPriceChangeStatistics24(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3TickerPriceChangeStatistics24 tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3TickerPriceChangeStatistics24();
    	DataSet OUT_DS =tmp.GetApiV3TickerPriceChangeStatistics24(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    public DataSet MarketDataEndPointsGetApiV3OldTradeLookup(DataSet InDs,String InDsNames, String outDsNames) throws Exception {
    	com.example.coin.binance.MarketDataEndPointsGetApiV3OldTradeLookup tmp = new com.example.coin.binance.MarketDataEndPointsGetApiV3OldTradeLookup();
    	DataSet OUT_DS =tmp.GetApiV3OldTradeLookup(InDs,InDsNames,outDsNames);
        return OUT_DS;
    }
    
    
}
